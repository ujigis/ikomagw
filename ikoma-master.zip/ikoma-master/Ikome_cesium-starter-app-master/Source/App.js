var viewer = new Cesium.Viewer('cesiumContainer');

